void initUart();
void Sender();
void UART_DRV(void);
void ModbusSlave();
