extern int State;
void initStateMachineTimer(void);
